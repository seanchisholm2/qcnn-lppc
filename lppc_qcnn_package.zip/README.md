# lppc-qcnn
A repository implementing a quantum convolutional neural network using the Pennylane QML package framework.
